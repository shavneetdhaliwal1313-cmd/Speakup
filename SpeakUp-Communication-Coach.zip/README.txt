SpeakUp Communication Coach

Open index.html in a browser to run the website locally. No server or dependencies are required.
